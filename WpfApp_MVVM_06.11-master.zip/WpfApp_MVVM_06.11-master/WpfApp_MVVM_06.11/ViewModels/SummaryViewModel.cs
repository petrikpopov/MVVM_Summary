﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfApp_MVVM_06._11.Models;

namespace WpfApp_MVVM_06._11.ViewModels
{
    public class SummaryViewModel:ViewModel_Base
    {
        private static readonly DependencyProperty SummaryInfoProperty;

        static SummaryViewModel()
        {
            SummaryInfoProperty = DependencyProperty.Register("SummaryInfo", typeof(string), typeof(MainViewModel));
        }

        public SummaryViewModel(SummaryModel model)
        {
            SummaryInfo = Info_G(model);
        }

        private string Info_G(SummaryModel model)
        {
            string eng = model.IsEnglish ? "yes" : "no";
            string armenia = model.IsArmenia ? "yes" : "no";
            string spanish = model.IsSpanish ? "yes" : "no";
            string german = model.IsGerman ? "yes" : "no"; 

            return $"Name:{model.Name}\nAge:{model.Age}\nIsEnglish:{eng}\nIsSpanish:{spanish}\nIsArmenia:{armenia}\nIsGerman:{german}\nEmail:{model.Email}\nPhone:{model.Phone}\nEducation:{model.Education}\nExperience:{model.Experience}\nSkills:{model.Skills}\t";
        }
        public string SummaryInfo
        {
            get { return (string)GetValue(SummaryInfoProperty); }
            set { SetValue(SummaryInfoProperty, value); }
        }


    }
}
