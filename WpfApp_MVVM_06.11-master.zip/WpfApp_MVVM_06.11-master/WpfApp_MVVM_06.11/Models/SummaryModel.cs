﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_MVVM_06._11.Models
{
    public class SummaryModel
    {
        public string Name { set; get; }
        public int Age { set; get; }
        public bool IsEnglish { set; get; }
        public bool IsSpanish { set; get; }
        public bool IsArmenia { set; get; }
        public bool IsGerman { set; get; }
        public string Email { set; get; }
        public string Phone { set; get; }
        public string Education { set; get; }
        public string Experience { set; get; }
        public string Skills { set; get; }

        public SummaryModel(string name, int age, bool english, bool spanish, bool armenia, bool german, string email, string phone, string education, string experience, string skills)
        {
            Name = name;
            Age = age;
            IsEnglish = english;
            IsSpanish = spanish;
            IsArmenia = armenia;
            IsGerman = german;
            Email = email;
            Phone = phone;
            Education = education;
            Experience = experience;
            Skills = skills;
        }

        public override string ToString()
        {
            return $"{Name}";
        }
    }

}
